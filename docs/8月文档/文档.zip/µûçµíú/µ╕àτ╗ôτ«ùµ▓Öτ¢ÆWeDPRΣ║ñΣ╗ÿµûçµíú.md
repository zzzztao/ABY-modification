# 清结算沙盒WeDPR交付文档

## 交付内容介绍

本文档为交付内容，部署部分见 [参考文档](##参考文档)

| 交付内容       | 部署方                 | 功能                                                         |
| -------------- | ---------------------- | ------------------------------------------------------------ |
| 可验证密文账本 | Coin发行方、收付汇机构 | - 发行、赎回、转账接口<br />- 数据存储服务，对Coin密钥进行管理 <br />- 业务AMOP通信功能，供转账前后对业务字段进行通信 |
| 数据导出服务   | Coin发行方             | - 实时查询链上数据，展示链上内容，导出密文计费信息           |
| 收费小工具     | 微众                   | - 对密文计费信息进行解密，获取计费信息                       |

[TOC]

## 可验证密文账本

- 交付内容1：Verifiable-Confidential-Ledger jar包，提供发行、赎回、转账、查询类接口，调用数据存储服务
- 交付内容2：数据存储服务，以服务形式管理Coin密钥，被Verifiable-Confidential-Ledger调用

| 接口名（请确认接口名）                                       | 接口介绍                 |
| ------------------------------------------------------------ | ------------------------ |
| public LedgerTransactionReceipt issueCredit(OrderInfo orderInfo) | 开具Coin                 |
| public LedgerTransactionReceipt fulfillCredit(OrderInfo orderInfo) | 赎回Coin                 |
| public LedgerTransactionReceipt transferCredit(OrderInfo orderInfo) | 转账Coin                 |
| public LedgerTransactionReceipt queryLedgerTransactionReceipt(String orderId) | 查询交易执行结果         |
| public long getUnspentAmount()                               | 查询当前本机构未花费余额 |
| public void getAMOP()                                        | 实现业务AMOP字段通信     |

```protobuf
// 订单信息
message OrderInfo {
	string id; // 订单号
	string sender; // 发送方
	string reciever; // 接收方，本金额Coin所有者
	uint64 value; // 本次金额
	string timestamp; // 本次订单时间
}
```

### issueCredit 发行

传入订单信息，向区块链异步发起发行请求，执行成功后会将发行的Coin计入数据存储服务，通过queryLedgerTransactionReceipt查询执行结果

- 输入
  - 订单信息 OrderInfo类型
- 输出
  - Null

### fulfillCredit 赎回

传入订单信息，根据订单信息中的金额向区块链异步发起赎回请求，执行成功后会更新数据存储服务，将赎回的Coin标记为无效，通过queryLedgerTransactionReceipt查询执行结果

- 输入
  - 订单信息 OrderInfo类型
- 输出
  - Null

### transferCredit 转账

传入订单信息，根据订单信息中的金额、接收方信息向区块链异步发起转账请求，执行成功后会更新数据存储服务，将转账消耗的Coin标记为无效，将新生成的Coin计入数据存储服务

发送方通过queryLedgerTransactionReceipt查询执行结果

接收方通过getUnspentAmount和orderId可知执行结果

- 输入
  - 订单信息 OrderInfo类型
- 输出
  - Null

### getUnspentAmount 查询余额

查询当前未花费余额

- 输入
  - Null
- 输出
  - 余额 long类型

### 业务AMOP接口

与模式1相同，完成业务所需字段AMOP通信

## 数据导出服务

- 交付内容：数据导出服务，服务形式提供，通过restful接口完成查询功能

详见[数据导出部署部署说明]()

| 接口url                                                      | 接口介绍                     |
| ------------------------------------------------------------ | ---------------------------- |
| /api/wedpr/vcl/v1/balance/total                              | 查询当前链上未花费总额       |
| /api/wedpr/vcl/v1/balance/user                               | 查询某机构当前链上未花费总额 |
| /api/wedpr/vcl/v1/orders/volume                              | 查询某个时间段内所有订单数目 |
| public String getBillingInfo(String startTime, String endTime) | 获取计费信息                 |

### 查询当前未花费总额

- 输入
  - 无
- 输出
  - 金额 long类型

### 查询某机构链上未花费总额

- 输入
  - 机构名称 string类型
- 输出
  - 金额 long类型

### 查询某时间段内订单总数

- 输入
  - 开始时间戳 截止时间戳 string类型 unix风格
- 输出
  - 订单总数 long类型

比较时间戳，获取订单号不同字段的总和

### 获取计费信息

- 输入
  - 开始时间戳 截止时间戳 string类型
- 输出
  - 密文 string类型，结果为订单号|查询开始时间戳|查询截止时间戳

比较时间戳，获取订单号不同字段的总和后，将时间戳信息，订单总数拼接成一个字段，使用配置字文件加载的pem格式公钥进行加密，返回string

### 存储设计

mysql中string存储使用varchar(1024)

| 类型   | 名称           | 备注                                             |
| ------ | -------------- | ------------------------------------------------ |
| String | commitment     | 数据主键，为commitment的base64编码，定长96个字符 |
| Bool   | status当前状态 | 0-未花费 1-已花费                                |
| string | Id订单号       | 交易订单号，为一串hash值                         |
| string | sender         | 发送方名称 如Asher                               |
| string | receiver       | 接收方名称 如Cary，当前commitment所有方          |
| long   | value          | 本commitment金额                                 |
| string | timestamp      | 本次交易时间                                     |

## 解密小工具

提供一个小工具（/dist），通过输入密文计费信息，解密返回以下信息：

```protobuf
message BillingInfo {
	string start_time = 1;
	string end_time = 2;
	int64 billing_number = 3;
}
```

## 日志规范

使用@Slf4j注解，先不用

| 模块                 | 模块关键字     |
| -------------------- | -------------- |
| AMOP转账逻辑         | VCL,AMOP       |
| 通用模块             | VCL,COMMON     |
| 回调模块             | VCL,CALLBACK   |
| 服务示例             | DEMO     |
| 数据存储服务调用模块 | VCL,SAFEKEEPER |
| 调用接口模块         | VCL,SERVICE    |

## 参考文档

[公开可验证密文账本使用说明](.WIP)

[AMOP业务模块使用说明](./)

[数据存储服务使用说明](./WIP)

[数据导出服务使用说明](./WIP)

